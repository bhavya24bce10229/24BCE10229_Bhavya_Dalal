package com.example.demo.controller;

import com.example.demo.model.Member;
import com.example.demo.model.Plan;
import com.example.demo.model.Trainer;
import com.example.demo.model.Equipment;

import com.example.demo.repository.MemberRepository;
import com.example.demo.repository.PlanRepository;
import com.example.demo.repository.TrainerRepository;
import com.example.demo.repository.EquipmentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import com.example.demo.model.Payment;
import com.example.demo.repository.PaymentRepository;


import java.util.List;

@RestController
@RequestMapping("/api")
public class MemberController {

    @Autowired private MemberRepository memberRepository;
    @Autowired private PaymentRepository paymentRepository;
    @Autowired private PlanRepository planRepository;
    @Autowired private TrainerRepository trainerRepository;
    @Autowired private EquipmentRepository equipmentRepository;

    // ==========================================
    // 1. MEMBERS ENDPOINTS (With Relationships)
    // ==========================================
    @PostMapping("/members")
    public ResponseEntity<Member> createMember(@RequestBody Member member) {
        return new ResponseEntity<>(memberRepository.save(member), HttpStatus.CREATED);
    }

    @GetMapping("/members")
    public List<Member> getAllMembers() { return memberRepository.findAll(); }

    @PutMapping("/members/{id}")
    public ResponseEntity<Member> updateMember(@PathVariable String id, @RequestBody Member details) {
        return memberRepository.findById(id).map(member -> {
            member.setName(details.getName());
            member.setEmail(details.getEmail());
            member.setGymPlan(details.getGymPlan());
            member.setPersonalTrainer(details.getPersonalTrainer());
            return ResponseEntity.ok(memberRepository.save(member));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/members/{id}")
    public ResponseEntity<Void> deleteMember(@PathVariable String id) {
        memberRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // ==========================================
    // 2. GYM PLANS ENDPOINTS
    // ==========================================
    @PostMapping("/plans")
    public ResponseEntity<Plan> createPlan(@RequestBody Plan plan) {
        return new ResponseEntity<>(planRepository.save(plan), HttpStatus.CREATED);
    }

    @GetMapping("/plans")
    public List<Plan> getAllPlans() { return planRepository.findAll(); }

    @PutMapping("/plans/{id}")
    public ResponseEntity<Plan> updatePlan(@PathVariable String id, @RequestBody Plan details) {
        return planRepository.findById(id).map(plan -> {
            plan.setPlanName(details.getPlanName());
            plan.setPrice(details.getPrice());
            plan.setDurationMonths(details.getDurationMonths());
            return ResponseEntity.ok(planRepository.save(plan));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/plans/{id}")
    public ResponseEntity<Void> deletePlan(@PathVariable String id) {
        planRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // ==========================================
    // 3. TRAINERS ENDPOINTS
    // ==========================================
    @PostMapping("/trainers")
    public ResponseEntity<Trainer> createTrainer(@RequestBody Trainer trainer) {
        return new ResponseEntity<>(trainerRepository.save(trainer), HttpStatus.CREATED);
    }

    @GetMapping("/trainers")
    public List<Trainer> getAllTrainers() { return trainerRepository.findAll(); }

    @PutMapping("/trainers/{id}")
    public ResponseEntity<Trainer> updateTrainer(@PathVariable String id, @RequestBody Trainer details) {
        return trainerRepository.findById(id).map(trainer -> {
            trainer.setName(details.getName());
            trainer.setSpecialization(details.getSpecialization());
            return ResponseEntity.ok(trainerRepository.save(trainer));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/trainers/{id}")
    public ResponseEntity<Void> deleteTrainer(@PathVariable String id) {
        trainerRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // ==========================================
    // 4. EQUIPMENT ENDPOINTS
    // ==========================================
    @PostMapping("/equipment")
    public ResponseEntity<Equipment> createEquipment(@RequestBody Equipment eq) {
        return new ResponseEntity<>(equipmentRepository.save(eq), HttpStatus.CREATED);
    }

    @GetMapping("/equipment")
    public List<Equipment> getAllEquipment() { return equipmentRepository.findAll(); }

    @PutMapping("/equipment/{id}")
    public ResponseEntity<Equipment> updateEquipment(@PathVariable String id, @RequestBody Equipment details) {
        return equipmentRepository.findById(id).map(eq -> {
            eq.setName(details.getName());
            eq.setStatus(details.getStatus());
            return ResponseEntity.ok(equipmentRepository.save(eq));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/equipment/{id}")
    public ResponseEntity<Void> deleteEquipment(@PathVariable String id) {
        equipmentRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
    

    // --- PAYMENT ENDPOINTS ---

    @PostMapping("/payments")
    public ResponseEntity<Payment> recordPayment(@RequestBody Payment payment) {
        return new ResponseEntity<>(paymentRepository.save(payment), HttpStatus.CREATED);
    }

    @GetMapping("/payments")
    public ResponseEntity<List<Payment>> getAllPayments() {
        return ResponseEntity.ok(paymentRepository.findAll());
    }


    // --- ADDITIONAL MEMBER ENDPOINTS ---





    // --- ADDITIONAL PAYMENT ENDPOINTS ---

    @PutMapping("/payments/{id}")
    public ResponseEntity<Payment> updatePayment(@PathVariable String id, @RequestBody Payment paymentDetails) {
        return paymentRepository.findById(id).map(payment -> {
            payment.setAmount(paymentDetails.getAmount());
            return ResponseEntity.ok(paymentRepository.save(payment));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/payments/{id}")
    public ResponseEntity<Void> deletePayment(@PathVariable String id) {
        if (paymentRepository.existsById(id)) {
            paymentRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }


    
} // This is the final closing bracket of the entire file