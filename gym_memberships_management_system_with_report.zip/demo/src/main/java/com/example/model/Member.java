package com.example.demo.model;
import org.springframework.data.mongodb.core.mapping.MongoId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DocumentReference;


@Document(collection = "members")
public class Member {
    @Id
    @MongoId
    private String id;
    private String name;
    private String email;

    // Connects Many Members to One Gym Plan
    @DocumentReference
    private Plan gymPlan;

    // Connects Many Members to One Trainer
    @DocumentReference
    private Trainer personalTrainer;

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public Plan getGymPlan() { return gymPlan; }
    public void setGymPlan(Plan gymPlan) { this.gymPlan = gymPlan; }
    public Trainer getPersonalTrainer() { return personalTrainer; }
    public void setPersonalTrainer(Trainer personalTrainer) { this.personalTrainer = personalTrainer; }
}