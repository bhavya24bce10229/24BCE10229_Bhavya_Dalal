package com.example.demo.model; // Ensure it includes .demo

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DocumentReference;
import java.util.Date;

@Document(collection = "payments")
public class Payment {
    @Id
    private String id;
    private double amount;
    private Date paymentDate = new Date();

    @DocumentReference
    private Member member;

    public Payment() {}
    public Payment(double amount, Member member) {
        this.amount = amount;
        this.member = member;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public Date getPaymentDate() { return paymentDate; }
    public void setPaymentDate(Date paymentDate) { this.paymentDate = paymentDate; }
    public Member getMember() { return member; }
    public void setMember(Member member) { this.member = member; }
}